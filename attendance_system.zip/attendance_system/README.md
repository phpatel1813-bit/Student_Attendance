# 🎓 Student Attendance System
### GTU Diploma — Information Technology — 1st Semester Project

---

## 📌 Project Details

| Field | Details |
|---|---|
| **Project Name** | Student Attendance System |
| **Language** | Python 3.x |
| **Subject** | Fundamentals of Programming with Python |
| **Institute** | GTU Affiliated Diploma Institute |
| **Branch** | Information Technology (IT) |
| **Semester** | 1st Semester |
| **Year** | 2024–25 |

---

## 📖 About the Project

The **Student Attendance System** is a menu-driven Python program that helps teachers manage student attendance records without any internet or database software. All data is saved in simple CSV files that can be opened in MS Excel.

This project demonstrates the following Python concepts taught in 1st semester:

- Variables and Data Types
- If-Else conditions
- Loops (while, for)
- Functions
- File Handling (CSV read/write)
- Lists and Dictionaries
- String operations
- `datetime` module
- `os` module

---

## 🚀 How to Run

### Step 1 — Make sure Python is installed
```
python --version
```
Should show Python 3.6 or higher.

### Step 2 — Download / Clone the project
```bash
git clone https://github.com/yourusername/student-attendance-system.git
cd student-attendance-system
```

### Step 3 — Run the program
```bash
python attendance.py
```

No extra libraries needed! Only built-in Python modules are used.

---

## 📋 Features

| # | Feature | Description |
|---|---|---|
| 1 | Add Student | Add student with roll no, name, branch |
| 2 | View Students | See all registered students in a table |
| 3 | Mark Attendance | Mark P/A/L for all students for today |
| 4 | View by Date | See attendance of any specific date |
| 5 | Student Report | Full report with attendance % for one student |
| 6 | Overall Summary | Attendance % for all students at once |
| 7 | Delete Student | Remove a student from the system |
| 8 | Exit | Exit the program safely |

---

## 📊 Attendance % Calculation

```
Attendance % = (Present + Late) / Total Classes × 100
```

- ✅ **≥ 75%** → GTU attendance requirement MET
- ⚠️  **< 75%** → LOW attendance (shows how many classes needed)

---

## 🗂️ File Structure

```
student-attendance-system/
│
├── attendance.py       ← Main Python program (run this)
├── students.csv        ← Auto-created when you add students
├── attendance.csv      ← Auto-created when you mark attendance
└── README.md           ← This file
```

> 💡 `students.csv` and `attendance.csv` are created automatically the first time you use the program.

---

## 💻 Sample Output

```
═══════════════════════════════════════════════════════
       🎓 STUDENT ATTENDANCE SYSTEM
       GTU Diploma IT — 1st Semester
═══════════════════════════════════════════════════════

   1. Add New Student
   2. View All Students
   3. Mark Attendance (Today)
   4. View Attendance by Date
   5. Student Attendance Report
   6. Overall Summary (All Students)
   7. Delete Student
   8. Exit
```

---

## 📄 Python Concepts Used (For Viva)

| Concept | Where Used |
|---|---|
| `def` Functions | Every feature is a separate function |
| `if / elif / else` | Menu choices, input validation |
| `while True` loop | Main menu loop, input retry loop |
| `for` loop | Displaying student lists, marking attendance |
| `open()` + CSV | Reading/writing students.csv and attendance.csv |
| `list` of `dict` | Storing student and attendance records |
| `datetime` module | Getting today's date and current time |
| `os` module | Clearing screen, checking file existence |
| `input()` | All user interactions |
| String `.strip()`, `.upper()`, `.title()` | Cleaning user input |

---

## 🖊️ Viva Questions & Answers

**Q1. What is a function in Python?**
A function is a block of reusable code defined using `def`. In this project, each feature (add student, mark attendance, etc.) is a separate function.

**Q2. What is file handling?**
File handling means reading from and writing to files. We use the built-in `open()` function with `csv` module to save student and attendance data permanently.

**Q3. What is a dictionary?**
A dictionary stores data as key-value pairs. Example: `{"roll": "IT001", "name": "Aarav", "branch": "IT"}`.

**Q4. What does `if __name__ == "__main__"` mean?**
It means: run `main_menu()` only when this file is run directly, not when it is imported in another file.

**Q5. What is the `datetime` module used for?**
To get today's date and current time automatically using `datetime.date.today()`.

---

## 👨‍💻 Made By

**[Your Name]**  
Roll No: [Your Roll No]  
Branch: Information Technology  
GTU Diploma — 1st Semester  
Year: 2024–25
