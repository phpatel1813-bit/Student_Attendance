"""
============================================================
  STUDENT ATTENDANCE SYSTEM
  GTU Diploma — Information Technology — 1st Semester
  Subject: Fundamentals of Programming with Python
============================================================
"""

import os
import csv
import datetime

# ─────────────────────────────────────────────────────────
# FILE NAMES  (data is saved in these CSV files)
# ─────────────────────────────────────────────────────────
STUDENTS_FILE   = "students.csv"
ATTENDANCE_FILE = "attendance.csv"


# ─────────────────────────────────────────────────────────
# HELPER FUNCTIONS
# ─────────────────────────────────────────────────────────

def clear_screen():
    """Clear the terminal screen."""
    os.system('cls' if os.name == 'nt' else 'clear')


def print_line(char="─", length=55):
    """Print a decorative line."""
    print(char * length)


def print_header(title):
    """Print a formatted section header."""
    print()
    print_line("═")
    print(f"  {title}")
    print_line("═")


def press_enter():
    """Pause and wait for the user."""
    print()
    input("  Press ENTER to continue...")


def today():
    """Return today's date as a string (DD-MM-YYYY)."""
    return datetime.date.today().strftime("%d-%m-%Y")


def now_time():
    """Return current time as a string (HH:MM)."""
    return datetime.datetime.now().strftime("%H:%M")


# ─────────────────────────────────────────────────────────
# FILE READ / WRITE HELPERS
# ─────────────────────────────────────────────────────────

def load_students():
    """
    Load all students from students.csv.
    Returns a list of dicts: [{'roll': ..., 'name': ..., 'branch': ...}, ...]
    """
    students = []
    if not os.path.exists(STUDENTS_FILE):
        return students
    with open(STUDENTS_FILE, "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            students.append(row)
    return students


def save_students(students):
    """Save the full students list back to students.csv."""
    with open(STUDENTS_FILE, "w", newline="") as f:
        fieldnames = ["roll", "name", "branch"]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(students)


def load_attendance():
    """
    Load all attendance records from attendance.csv.
    Returns list of dicts: [{'roll', 'name', 'date', 'time', 'status'}, ...]
    """
    records = []
    if not os.path.exists(ATTENDANCE_FILE):
        return records
    with open(ATTENDANCE_FILE, "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            records.append(row)
    return records


def save_attendance_record(record):
    """Append a single attendance record to attendance.csv."""
    file_exists = os.path.exists(ATTENDANCE_FILE)
    with open(ATTENDANCE_FILE, "a", newline="") as f:
        fieldnames = ["roll", "name", "date", "time", "status"]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        if not file_exists:
            writer.writeheader()
        writer.writerow(record)


def find_student_by_roll(roll):
    """Find and return a student dict by roll number, or None."""
    students = load_students()
    for s in students:
        if s["roll"].strip().upper() == roll.strip().upper():
            return s
    return None


# ─────────────────────────────────────────────────────────
# FEATURE 1 — ADD STUDENT
# ─────────────────────────────────────────────────────────

def add_student():
    print_header("ADD NEW STUDENT")

    roll = input("  Enter Roll Number  : ").strip().upper()
    if not roll:
        print("  ❌ Roll number cannot be empty!")
        press_enter()
        return

    # Check duplicate
    if find_student_by_roll(roll):
        print(f"  ❌ Student with Roll No '{roll}' already exists!")
        press_enter()
        return

    name = input("  Enter Student Name : ").strip().title()
    if not name:
        print("  ❌ Name cannot be empty!")
        press_enter()
        return

    print("  Branch options     : IT / CE / ME / EC / Civil")
    branch = input("  Enter Branch       : ").strip().upper()

    students = load_students()
    students.append({"roll": roll, "name": name, "branch": branch})
    save_students(students)

    print()
    print("  ✅ Student added successfully!")
    print(f"     Roll: {roll}  |  Name: {name}  |  Branch: {branch}")
    press_enter()


# ─────────────────────────────────────────────────────────
# FEATURE 2 — VIEW ALL STUDENTS
# ─────────────────────────────────────────────────────────

def view_all_students():
    print_header("ALL STUDENTS")

    students = load_students()

    if not students:
        print("  No students found. Please add students first.")
        press_enter()
        return

    print(f"  {'#':<4} {'Roll No':<12} {'Name':<25} {'Branch'}")
    print_line()
    for i, s in enumerate(students, 1):
        print(f"  {i:<4} {s['roll']:<12} {s['name']:<25} {s['branch']}")

    print_line()
    print(f"  Total Students: {len(students)}")
    press_enter()


# ─────────────────────────────────────────────────────────
# FEATURE 3 — MARK ATTENDANCE
# ─────────────────────────────────────────────────────────

def mark_attendance():
    print_header("MARK ATTENDANCE")

    students = load_students()

    if not students:
        print("  ❌ No students found. Please add students first.")
        press_enter()
        return

    date = today()
    print(f"  📅 Today's Date : {date}")
    print(f"  🕒 Time         : {now_time()}")
    print()
    print("  Enter 'P' for Present, 'A' for Absent, 'L' for Late")
    print_line()

    marked_today = []
    existing_records = load_attendance()

    # Check who is already marked today
    already_marked = set()
    for rec in existing_records:
        if rec["date"] == date:
            already_marked.add(rec["roll"])

    count_marked = 0
    for s in students:
        roll = s["roll"]
        name = s["name"]

        if roll in already_marked:
            print(f"  {roll:<12} {name:<25} → Already marked today (skipped)")
            continue

        while True:
            status_input = input(f"  {roll:<12} {name:<25} → [P/A/L]: ").strip().upper()
            if status_input in ("P", "A", "L"):
                break
            print("    Please enter P, A, or L only.")

        if status_input == "P":
            status = "Present"
        elif status_input == "A":
            status = "Absent"
        else:
            status = "Late"

        record = {
            "roll":   roll,
            "name":   name,
            "date":   date,
            "time":   now_time(),
            "status": status
        }
        save_attendance_record(record)
        count_marked += 1

    print()
    if count_marked > 0:
        print(f"  ✅ Attendance marked for {count_marked} student(s) on {date}.")
    else:
        print(f"  ℹ️  All students were already marked for today ({date}).")
    press_enter()


# ─────────────────────────────────────────────────────────
# FEATURE 4 — VIEW ATTENDANCE BY DATE
# ─────────────────────────────────────────────────────────

def view_attendance_by_date():
    print_header("VIEW ATTENDANCE BY DATE")

    print(f"  Today is: {today()}")
    date_input = input("  Enter Date (DD-MM-YYYY) or press ENTER for today: ").strip()
    if not date_input:
        date_input = today()

    records = load_attendance()
    day_records = [r for r in records if r["date"] == date_input]

    if not day_records:
        print(f"\n  No attendance records found for {date_input}.")
        press_enter()
        return

    print(f"\n  📅 Attendance for : {date_input}")
    print_line()
    print(f"  {'#':<4} {'Roll No':<12} {'Name':<25} {'Time':<8} {'Status'}")
    print_line()

    present = 0
    absent  = 0
    late    = 0

    for i, r in enumerate(day_records, 1):
        status = r["status"]
        # Simple symbol next to status
        symbol = "✅" if status == "Present" else ("❌" if status == "Absent" else "⏰")
        print(f"  {i:<4} {r['roll']:<12} {r['name']:<25} {r['time']:<8} {symbol} {status}")

        if status == "Present": present += 1
        elif status == "Absent": absent += 1
        else: late += 1

    print_line()
    total = present + absent + late
    print(f"  Present: {present}  |  Absent: {absent}  |  Late: {late}  |  Total: {total}")
    press_enter()


# ─────────────────────────────────────────────────────────
# FEATURE 5 — VIEW STUDENT ATTENDANCE REPORT
# ─────────────────────────────────────────────────────────

def student_report():
    print_header("STUDENT ATTENDANCE REPORT")

    roll = input("  Enter Student Roll Number: ").strip().upper()
    student = find_student_by_roll(roll)

    if not student:
        print(f"  ❌ No student found with Roll No '{roll}'.")
        press_enter()
        return

    records = load_attendance()
    student_records = [r for r in records if r["roll"] == roll]

    if not student_records:
        print(f"\n  No attendance records found for {student['name']}.")
        press_enter()
        return

    print(f"\n  👤 Name   : {student['name']}")
    print(f"  📋 Roll   : {student['roll']}")
    print(f"  🏫 Branch : {student['branch']}")
    print_line()
    print(f"  {'#':<4} {'Date':<14} {'Time':<8} {'Status'}")
    print_line()

    present = 0
    absent  = 0
    late    = 0

    for i, r in enumerate(student_records, 1):
        status = r["status"]
        symbol = "✅" if status == "Present" else ("❌" if status == "Absent" else "⏰")
        print(f"  {i:<4} {r['date']:<14} {r['time']:<8} {symbol} {status}")
        if status == "Present": present += 1
        elif status == "Absent": absent += 1
        else: late += 1

    total = present + absent + late
    # Count Present + Late both as "attended"
    attended = present + late

    print_line()
    print(f"  Total Classes : {total}")
    print(f"  Present       : {present}")
    print(f"  Absent        : {absent}")
    print(f"  Late          : {late}")

    if total > 0:
        percentage = round((attended / total) * 100, 2)
        print(f"  Attendance %  : {percentage}%")
        print()
        if percentage >= 75:
            print(f"  🎉 Status: GOOD  (≥ 75% — GTU requirement met)")
        else:
            shortfall = int((0.75 * total - attended))
            print(f"  ⚠️  Status: LOW  (Below 75% — Need {shortfall} more class(es))")

    press_enter()


# ─────────────────────────────────────────────────────────
# FEATURE 6 — DELETE STUDENT
# ─────────────────────────────────────────────────────────

def delete_student():
    print_header("DELETE STUDENT")

    roll = input("  Enter Roll Number to delete: ").strip().upper()
    students = load_students()

    found = False
    updated = []
    for s in students:
        if s["roll"] == roll:
            found = True
            print(f"\n  Found: {s['name']} ({s['roll']}) — {s['branch']}")
        else:
            updated.append(s)

    if not found:
        print(f"  ❌ No student found with Roll No '{roll}'.")
        press_enter()
        return

    confirm = input("  Are you sure you want to delete? (yes/no): ").strip().lower()
    if confirm == "yes":
        save_students(updated)
        print("  ✅ Student deleted successfully.")
    else:
        print("  ❌ Deletion cancelled.")

    press_enter()


# ─────────────────────────────────────────────────────────
# FEATURE 7 — OVERALL SUMMARY
# ─────────────────────────────────────────────────────────

def overall_summary():
    print_header("OVERALL ATTENDANCE SUMMARY")

    students = load_students()
    records  = load_attendance()

    if not students:
        print("  No students found.")
        press_enter()
        return

    if not records:
        print("  No attendance records found.")
        press_enter()
        return

    print(f"  {'Roll':<12} {'Name':<25} {'Classes':<10} {'Present':<10} {'%':<8} {'Status'}")
    print_line()

    for s in students:
        roll = s["roll"]
        name = s["name"]
        s_recs = [r for r in records if r["roll"] == roll]
        total   = len(s_recs)
        present = sum(1 for r in s_recs if r["status"] in ("Present", "Late"))
        absent  = total - present

        if total > 0:
            pct = round((present / total) * 100, 1)
            status = "✅ OK" if pct >= 75 else "⚠️  LOW"
        else:
            pct = 0.0
            status = "— No Data"

        print(f"  {roll:<12} {name:<25} {total:<10} {present:<10} {str(pct)+'%':<8} {status}")

    print_line()
    print(f"  Total Students: {len(students)}  |  Total Records: {len(records)}")
    press_enter()


# ─────────────────────────────────────────────────────────
# MAIN MENU
# ─────────────────────────────────────────────────────────

def main_menu():
    while True:
        clear_screen()
        print()
        print_line("═")
        print("       🎓 STUDENT ATTENDANCE SYSTEM")
        print("       GTU Diploma IT — 1st Semester")
        print_line("═")
        print()
        print("   1. Add New Student")
        print("   2. View All Students")
        print("   3. Mark Attendance (Today)")
        print("   4. View Attendance by Date")
        print("   5. Student Attendance Report")
        print("   6. Overall Summary (All Students)")
        print("   7. Delete Student")
        print("   8. Exit")
        print()
        print_line()

        choice = input("   Enter your choice (1-8): ").strip()

        if   choice == "1": add_student()
        elif choice == "2": view_all_students()
        elif choice == "3": mark_attendance()
        elif choice == "4": view_attendance_by_date()
        elif choice == "5": student_report()
        elif choice == "6": overall_summary()
        elif choice == "7": delete_student()
        elif choice == "8":
            print()
            print("  👋 Thank you! Exiting the system.")
            print()
            break
        else:
            print()
            print("  ❌ Invalid choice! Please enter a number from 1 to 8.")
            press_enter()


# ─────────────────────────────────────────────────────────
# PROGRAM STARTS HERE
# ─────────────────────────────────────────────────────────

if __name__ == "__main__":
    main_menu()
