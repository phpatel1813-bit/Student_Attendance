"""
demo_data.py — Run this once to load sample students for testing.
Usage: python demo_data.py
"""

import csv
import os

STUDENTS_FILE = "students.csv"
ATTENDANCE_FILE = "attendance.csv"

sample_students = [
    {"roll": "IT2401", "name": "Aarav Shah",    "branch": "IT"},
    {"roll": "IT2402", "name": "Priya Patel",   "branch": "IT"},
    {"roll": "IT2403", "name": "Rahul Mehta",   "branch": "IT"},
    {"roll": "IT2404", "name": "Sonal Desai",   "branch": "IT"},
    {"roll": "IT2405", "name": "Karan Joshi",   "branch": "IT"},
]

sample_attendance = [
    {"roll": "IT2401", "name": "Aarav Shah",  "date": "01-06-2024", "time": "09:00", "status": "Present"},
    {"roll": "IT2402", "name": "Priya Patel", "date": "01-06-2024", "time": "09:01", "status": "Present"},
    {"roll": "IT2403", "name": "Rahul Mehta", "date": "01-06-2024", "time": "09:02", "status": "Absent"},
    {"roll": "IT2404", "name": "Sonal Desai", "date": "01-06-2024", "time": "09:03", "status": "Late"},
    {"roll": "IT2405", "name": "Karan Joshi", "date": "01-06-2024", "time": "09:04", "status": "Present"},
    {"roll": "IT2401", "name": "Aarav Shah",  "date": "02-06-2024", "time": "09:00", "status": "Present"},
    {"roll": "IT2402", "name": "Priya Patel", "date": "02-06-2024", "time": "09:01", "status": "Absent"},
    {"roll": "IT2403", "name": "Rahul Mehta", "date": "02-06-2024", "time": "09:02", "status": "Present"},
    {"roll": "IT2404", "name": "Sonal Desai", "date": "02-06-2024", "time": "09:03", "status": "Present"},
    {"roll": "IT2405", "name": "Karan Joshi", "date": "02-06-2024", "time": "09:04", "status": "Present"},
]

# Write students
with open(STUDENTS_FILE, "w", newline="") as f:
    writer = csv.DictWriter(f, fieldnames=["roll", "name", "branch"])
    writer.writeheader()
    writer.writerows(sample_students)

# Write attendance
with open(ATTENDANCE_FILE, "w", newline="") as f:
    writer = csv.DictWriter(f, fieldnames=["roll", "name", "date", "time", "status"])
    writer.writeheader()
    writer.writerows(sample_attendance)

print("✅ Demo data loaded successfully!")
print(f"   {len(sample_students)} students added.")
print(f"   {len(sample_attendance)} attendance records added.")
print()
print("Now run: python attendance.py")
